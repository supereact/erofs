/* SPDX-License-Identifier: GPL-2.0+ */
#ifdef __APPLE__
#undef LIST_HEAD
#endif
