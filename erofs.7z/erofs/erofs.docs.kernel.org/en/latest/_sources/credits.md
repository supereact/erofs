# 🎉 Contributors

EROFS has been contributed by community developers around the world,
including but not limited to (in alphabetical order):

 * By vendor ([raw](https://github.com/erofs/docs/actions/runs/7959034932))
     - Alibaba Group (@linux.alibaba.com)
     - ByteDance (@bytedance.com)
     - Coolpad (@coolpad.com, @yulong.com)
     - Google (@google.com)
     - Huawei (@huawei.com)
     - OPPO (@oppo.com)
     - Red Hat (@redhat.com)
     - Shanghai Jiao Tong University (@sjtu.edu.cn)
     - South China University of Technology (@mail.scut.edu.cn)
     - Tuxera (@tuxera.com)
     - Uniontech (@uniontech.com)
     - Vivo (@vivo.com)

  * Individuals

Since it's _an incomplete list_, feel free to submit a pull request to
add yourself here if you'd like to be highlighted as an EROFS
contributor.
